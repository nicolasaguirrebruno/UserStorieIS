﻿using System;

public class Gradient
{
	holas e jqwewq ejwq e jqwe jqwne jwq  
	
}
